"""
Created by:
Hugo Herrador Segade h.herrador@udc.es
Pablo Montes Aldao pablomontes1@udc.es

Work licensed under a GPL 3.0 License (see LICENSE file)
"""


from manager import *

def main():
    manager = Manager()
    manager.launch()

if __name__ == "__main__":
    main()